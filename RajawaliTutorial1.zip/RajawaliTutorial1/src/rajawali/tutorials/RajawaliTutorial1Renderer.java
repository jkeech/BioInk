package rajawali.tutorials;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import rajawali.lights.DirectionalLight;
import rajawali.materials.DiffuseMaterial;
import rajawali.primitives.Sphere;
import rajawali.renderer.RajawaliRenderer;

public class RajawaliTutorial1Renderer extends RajawaliRenderer {

	DirectionalLight mLight;
	Sphere mSphere;
	
	public RajawaliTutorial1Renderer(Context context) {
		super(context);
		setFrameRate(30);
	} 

	@Override
	public void initScene() { 
		mLight = new DirectionalLight(1f, 0.2f, 1.0f); // set the direction
		mLight.setColor(1.0f, 1.0f, 1.0f);
		mLight.setPower(2);

//		Bitmap bg = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.earthtruecolor_nasa_big);
		Bitmap bg = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.selera_sari);
		DiffuseMaterial material = new DiffuseMaterial();
		mSphere = new Sphere(1, 18, 18);
		mSphere.setMaterial(material);
		mSphere.addLight(mLight);
		mSphere.addTexture(mTextureManager.addTexture(bg));
		addChild(mSphere);

		mCamera.setZ(-4.2f);
	} 

	public void onSurfaceCreated(){
//		mLight = new DirectionalLight(0.1f, 0.2f, 1.0f); // set the direction
//		mLight.setPower(1.5f);
//		Bitmap bg = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.selera_sari);
//		mSphere = new Sphere(1, 12, 12);
//		DiffuseMaterial material = new DiffuseMaterial();
//		mSphere.setMaterial(material);
//		mSphere.setLight(mLight);
//		mSphere.addTexture(mTextureManager.addTexture(bg));
//		addChild(mSphere);
//		mCamera.setZ(-4.2f);
			Log.d("shit", "shit");
	}
	@Override 
	public void onDrawFrame(GL10 glUnused) {
		super.onDrawFrame(glUnused);
		if(mSphere==null){Log.d("fuck", "fuck");}else{
			mSphere.setRotY(mSphere.getRotY() + 1);
		}
	}
}
